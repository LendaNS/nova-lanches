# Nova Lanches

Site simples para restaurante/lanchonete com integração ao WhatsApp.

## Como publicar no Vercel

1. Faça login em https://vercel.com com sua conta GitHub.
2. Clique em **Add New > Project**.
3. Selecione o repositório com esses arquivos.
4. Clique em **Deploy**.

Pronto! O site estará online no domínio da Vercel.

